print("More sales initialized", __name__)


def calc_tax():
    print("Calculate the tax value.")


def calc_shipping():
    print("Calculate the shipping cost.")


if __name__ == "__main__":
    print("More sales started")
    calc_tax()
